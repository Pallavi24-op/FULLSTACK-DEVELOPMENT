from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import BlogListView, BlogDetailView, BlogCreateView

urlpatterns = [
    path('', BlogListView.as_view(), name='blog_list'),  # /blogs/ → List all blog posts
    path('<int:pk>/', BlogDetailView.as_view(), name='blog_detail'),  # /blogs/<int:id>/ → View a single post
    path('new/', BlogCreateView.as_view(), name='blog_create'),  # /blogs/new/ → Create a blog post
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
    